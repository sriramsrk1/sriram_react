# TabooCard

This project downloaded from Appitr IDE.

## Run Insturactions
```bash

# Setup Project
npm run setup

# Run Ios
react-native run-ios

# Run Android
react-native run-android

```
