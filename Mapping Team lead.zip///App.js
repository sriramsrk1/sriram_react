import React, { Component } from 'react';
import { AppRegistry } from 'react-native';
import { View, Text, Button } from 'native-base';
import GenerateForm from 'react-native-form-builder';

const styles = {
  wrapper: {
    flex: 1,
    marginTop: 150,
  },
  submitButton: {
    paddingHorizontal: 10,
    paddingTop: 20,
  },
};

const fields = [
  {
    type: 'text',
    name: 'emp_name',
    required: true,
    icon: 'ios-person',
    label: 'Employee',
  },
  {
    type: 'text',
    name: 'emp_role',
    icon: 'ios-person',
    required: true,
    label: 'Role',
  },
  {
    type: 'picker',
    name: 'team_lead',
    mode: 'dialog',
    label: 'Team Lead',
    defaultValue: '',
    options: ['John', 'Joe', 'Natasha', 'Frank', 'Emily'],
  },
];
export default class FormGenerator extends Component {
  Login() {
    const formValues = this.formGenerator.getValues();
    console.log('FORM VALUES', formValues);
  }
  render() {
    return (
      <View style={styles.wrapper}>
        <View>
          <GenerateForm
            ref={(c) => {
              this.formGenerator = c;
            }}
            fields={fields}
          />
        </View>
        <View style={styles.submitButton}>
          <Button block onPress={() => this.Login()}>
            <Text>Add Employee</Text>
          </Button>
        </View>
      </View>
    );
  }
}

AppRegistry.registerComponent('FormGenerator', () => FormGenerator);
